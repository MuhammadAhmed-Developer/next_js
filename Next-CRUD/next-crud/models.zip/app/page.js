import TopicLists from "./(components)/TopicList";

export default function Home() {
  return (
    <>
    <TopicLists/>
    </>
    
      
  )
}
